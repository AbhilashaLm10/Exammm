import { Component, OnInit } from '@angular/core';
import { TodoModel } from '../Model/TodoModel';
import { TodoService } from '../Service/todo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  todo:TodoModel;
  constructor(private service:TodoService,private route:Router) { 
    this.todo=new TodoModel();
  }

  ngOnInit() {
  }

  add(){
    this.todo.status='Incomplete';
    this.service.add(this.todo);
    this.route.navigate(['/todo']);
    

  }

}
