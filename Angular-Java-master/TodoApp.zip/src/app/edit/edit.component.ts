import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { TodoService } from '../Service/todo.service';
import { TodoModel } from '../Model/TodoModel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
todo:TodoModel;
  constructor(private service:TodoService ,private route:Router) {
    this.todo=new TodoModel();
   }

  ngOnInit() {
    this.todo=this.service.edit(this.service.get());
  }
update(){
this.route.navigate(['/todo'])
} 
}
