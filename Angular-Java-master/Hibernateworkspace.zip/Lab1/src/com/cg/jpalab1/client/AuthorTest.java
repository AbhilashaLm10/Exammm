package com.cg.jpalab1.client;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpalab1.entity.Author;
import com.cg.jpalab1.service.AuthorService;
import com.cg.jpalab1.service.IAuthorService;

public class AuthorTest {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		IAuthorService service=new AuthorService();
		Author author=new Author();
		System.out.println("Enter First Name");
		String Fname=sc.next();
		System.out.println("Enter Middle Name");
		String Mname=sc.next();
		System.out.println("Enter Last Name");
		String Lname=sc.next();
		author.setFirstName(Fname);
		author.setLastName(Lname);
		author.setMiddleName(Mname);
		System.out.println("Enter Phone no");
		long phone=sc.nextLong();
		author.setPhoneNo(phone);
		//creating author
		service.addAuthor(author);

		//fetch by Id
		System.out.println("Enter Author Id");
		service.findAuthorById(sc.nextInt());
		
		//Update 
		author.setLastName("Jobs");
		service.updateAuthor(author);
		
		//fetch by Mobile
		System.out.println("Enter Phone no");
		service.findAuthorByMobile(sc.nextLong());
		
		//remove by Id
		System.out.println("Enter Author Id to be removed");
		service.removeAuthorById(sc.nextInt());
		
	}

}
