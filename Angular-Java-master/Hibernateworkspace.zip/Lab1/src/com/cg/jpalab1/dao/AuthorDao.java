package com.cg.jpalab1.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.jpalab1.entity.Author;

public class AuthorDao implements IAuthorDao{
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	Author author;

	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.merge(author);
		em.getTransaction().commit();	
	}

	@Override
	public void removeAuthorById(int id) {
		// TODO Auto-generated method stub
		author=em.find(Author.class, id);
		em.remove(author);
	}

	@Override
	public Author findAuthorById(int id) {
		// TODO Auto-generated method stub
		
		return em.find(Author.class, id);
	}

	@Override
	public void findAuthorByMobile(long phone) {
		// TODO Auto-generated method stub
		try {
			String str="select mob from Author mob where mob.phoneNo=:pphone";
			TypedQuery<Author> txn=em.createQuery(str, Author.class);
			txn.setParameter("pphone", phone);
			author=txn.getSingleResult();
			if(author!=null)
				System.out.println(author);
		} catch (Exception e) {
			System.out.println("Invalid Mobile no or Mobile no not exist");
		}
	}

	

}
