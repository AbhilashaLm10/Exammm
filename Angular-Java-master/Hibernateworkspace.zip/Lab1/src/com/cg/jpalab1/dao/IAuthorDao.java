package com.cg.jpalab1.dao;

import com.cg.jpalab1.entity.Author;

public interface IAuthorDao {
	public void addAuthor(Author author);

	public void updateAuthor(Author author);

	public void removeAuthorById(int id);

	public Author findAuthorById(int id);
	
	public void findAuthorByMobile(long phone);
}
