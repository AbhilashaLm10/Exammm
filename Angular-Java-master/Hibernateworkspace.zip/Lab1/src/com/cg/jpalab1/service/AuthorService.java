package com.cg.jpalab1.service;

import com.cg.jpalab1.dao.AuthorDao;
import com.cg.jpalab1.dao.IAuthorDao;
import com.cg.jpalab1.entity.Author;

public class AuthorService implements IAuthorService {
IAuthorDao dao=new AuthorDao();
	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.addAuthor(author);
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.updateAuthor(author);
	}

	@Override
	public void findAuthorById(int id) {
		Author a=dao.findAuthorById(id);
		if(a!=null)
			System.out.println(a);
		else {
			System.out.println("Author Id doesn't Exist");
		}
	}

	@Override
	public void removeAuthorById(int id) {
		// TODO Auto-generated method stub
		dao.removeAuthorById(id);
	}

	@Override
	public void findAuthorByMobile(long phone) {
		// TODO Auto-generated method stub
		dao.findAuthorByMobile(phone);
	}


}
