package com.cg.jpalab1.service;

import com.cg.jpalab1.entity.Author;

public interface IAuthorService {
	public void addAuthor(Author author);

	public void updateAuthor(Author author);

	public void removeAuthorById(int id);

	public void findAuthorById(int id);
	public void findAuthorByMobile(long phone);
}
