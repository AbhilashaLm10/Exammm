package com.jpa.lab2.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="Book2")
public class Book {
	
	@Id
	@Column(length=4)
	private int ISBN;
	@Column(length=40)
	private String Title;
	@Column(length=5)
	private int Price;
	
	@ManyToMany(mappedBy="books")
	private Set<Author> author=new HashSet<Author>();

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public Set<Author> getAuthor() {
		return author;
	}

	public void setAuthor(Set<Author> author) {
		this.author = author;
	}

	public void writtenBy(Author author) {
		this.getAuthor().add(author);
		
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", Title=" + Title + ", Price=" + Price
				+ "]";
	}


}
