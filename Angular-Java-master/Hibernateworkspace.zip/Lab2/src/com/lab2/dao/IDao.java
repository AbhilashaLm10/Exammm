package com.lab2.dao;

public interface IDao {

}
