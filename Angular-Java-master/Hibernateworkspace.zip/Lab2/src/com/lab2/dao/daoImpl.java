package com.lab2.dao;

public class daoImpl implements IDao {

}
