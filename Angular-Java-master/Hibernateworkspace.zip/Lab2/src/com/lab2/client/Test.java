package com.lab2.client;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.jpa.lab2.entity.Author;
import com.jpa.lab2.entity.Book;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Author author;
		/*//create books
		
		Book book1=new Book();
		book1.setISBN(50);
		book1.setTitle("Bigest Lie");
		book1.setPrice(500);
		
		Book book2=new Book();
		book2.setISBN(51);
		book2.setTitle("Scars which don't count");
		book2.setPrice(550);
		
		Book book3=new Book();
		book3.setISBN(53);
		book3.setTitle("Thank You");
		book3.setPrice(650);
		
		Book book4=new Book();
		book4.setISBN(54);
		book4.setTitle("Song of Ice and Fire");
		book4.setPrice(850);
		
		
		Author author1=new Author();
		author1.setName("Robin Sharma");
		
		author1.belongsTo(book2);
		author1.belongsTo(book3);
		book2.writtenBy(author1);
		book3.writtenBy(author1);
		
		Author author2=new Author();
		author2.setName("Chetan Bhagat");
		author2.belongsTo(book1);
		book1.writtenBy(author2);
		
		Author author3=new Author();
		author3.setName("R R Martin");
		author3.belongsTo(book4);
		book4.writtenBy(author3);
		
		em.persist(author1);
		em.persist(author2);
		em.persist(author3);
		
		System.out.println("Added to tables");*/
		
		//query1
		String str1="Select books from Book books";
		TypedQuery<Book> q=em.createQuery(str1, Book.class);
		List<Book> list1=q.getResultList();
		
		for (Book book : list1) {
			System.out.println(book);
		}
		
		
		//query2
		System.out.println("1. Robin Sharma\n2. Chetan Bhagat\n3. R R Martin");
		int opted=sc.nextInt();
		switch (opted) {
		case 1:String str2="select b from Author b where b.name='Robin Sharma'";
		TypedQuery<Author> query1=em.createQuery(str2, Author.class);
		author=query1.getSingleResult();
		Set<Book> set1= author.getBooks();
		for (Book book : set1) {
			System.out.println(book);
		}
		break;
		
		case 2:String str3="select b from Author b where b.name='Chetan Bhagat'";
		TypedQuery<Author> query2=em.createQuery(str3, Author.class);
		author=query2.getSingleResult();
		Set<Book> set2= author.getBooks();
		for (Book book : set2) {
			System.out.println(book);
		}
		break;
		
		case 3:String str4="select b from Author b where b.name='R R Martin'";
		TypedQuery<Author> query3=em.createQuery(str4, Author.class);
		author=query3.getSingleResult();
		Set<Book> set3= author.getBooks();
		for (Book book : set3) {
			System.out.println(book);
		}
		break;

		default:System.out.println("Invalid option");
			break;
		}
		
		//query3
		String str5="select bk from Book bk where bk.Price between 500 and 1000";
		TypedQuery<Book> query4=em.createQuery(str5, Book.class);
		List<Book> names=query4.getResultList();
		for (Book book : names) {
			System.out.println(book.getTitle());
		}
		
		//query4
		System.out.println("Enter book id:");
		int id=sc.nextInt();
		String str6="Select books from Book books where books.ISBN=:id";
		TypedQuery<Book> query5=em.createQuery(str6, Book.class);
		query5.setParameter("id", id);
		Book bk=query5.getSingleResult();
		Set<Author> auth=bk.getAuthor();
		for (Author author4 : auth) {
			System.out.println(author4.getName());
		}
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		
		
		
		
	}

}
