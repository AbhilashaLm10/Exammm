package com.lab2.service;

public interface IService {

}
