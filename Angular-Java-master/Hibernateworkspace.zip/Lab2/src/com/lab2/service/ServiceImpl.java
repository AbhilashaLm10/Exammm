package com.lab2.service;

public class ServiceImpl implements IService {

}
