package Dao;

import java.sql.SQLException;
import java.util.List;

import Main.Customer;

public interface BankDaoInterface {
	
	
	List<Customer> displayData(int id);
	
void storeIntoBank(int id,Customer customer);
	
	double showBalance(int id);
	void Deposit(int id, double amount);
	void Withdraw(int id,double amount);
	void fundTransfer(int id,int acc,double amount);
	void printTransactions(int id);
	public boolean idExist(int id);

}
