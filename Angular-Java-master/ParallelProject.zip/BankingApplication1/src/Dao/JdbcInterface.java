package Dao;

import java.sql.SQLException;

public interface JdbcInterface {

	double showBalance(int id);
	void Deposit(int id, double amount) throws SQLException;
	void Withdraw(int id,double amount);
	void fundTransfer(int id,int acc,double amount) throws SQLException;
	void printTransactions(int id);
	public boolean idExist(int id);
}
