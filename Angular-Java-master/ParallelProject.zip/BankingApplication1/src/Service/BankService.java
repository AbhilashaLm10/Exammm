package Service;

import java.sql.SQLException;
import java.util.List;

import Dao.BankDao;
import Dao.BankDaoInterface;
import Dao.JdbcDao;
import Main.Customer;

public class BankService implements BankServiceInterface {
	BankDaoInterface dao = new BankDao();
	JdbcDao jdao = new JdbcDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateMobile(String mobile) {

		if (mobile.matches(userNumberPattern)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateUserAge(String userAge) {
		if (userAge.matches(agePattern)) {
			if (Integer.valueOf(userAge) > 15)
				return true;
		}
		return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateEmail(String useraMail) {
		if (useraMail.matches(userMailPattern)) {
			return true;
		}
		return false;
	}

	@Override
	public List<Customer> displayData(int id) {
		return dao.displayData(id);
	}

	/*
	 * @Override public double showBalance(int id) { return
	 * customer.getBalance(); }
	 * 
	 * @Override public void Deposit(int id, double amount ) { double
	 * bal=customer.getBalance(); bal+=amount; customer.setBalance(bal); }
	 * 
	 * 
	 * @Override public void Withdraw(int id, double amount) { double
	 * bal=customer.getBalance(); if(bal>=amount) { bal-=amount;
	 * customer.setBalance(bal); } else
	 * System.out.println("Insufficient Fund!");
	 * 
	 * 
	 * }
	 * 
	 * @Override public void fundTransfer(int id,int acc,double amount) { double
	 * bal=customer.getBalance(); if(bal>=amount) { bal-=amount;
	 * System.out.println(amount+" Transferred to Account "+acc);
	 * customer.setBalance(bal); } else
	 * System.out.println("Insufficient Fund!");
	 * 
	 * 
	 * 
	 * }
	 */

	@Override
	public void storeIntoBank(int id, Customer customer) {
		dao.storeIntoBank(id, customer);
		jdao.openAccount(id, customer);

	}

	@Override
	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		dao.printTransactions(id);
		jdao.printTransactions(id);
	}

	@Override
	public double showBalance(int id) {
		// TODO Auto-generated method stub
		return dao.showBalance(id);
	}

	@Override
	public void Deposit(int id, double amount) {
		// TODO Auto-generated method stub
		dao.Deposit(id, amount);
		try {
			jdao.Deposit(id, amount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void Withdraw(int id, double amount) {
		// TODO Auto-generated method stub
		dao.Withdraw(id, amount);
		jdao.Withdraw(id, amount);
	}

	@Override
	public void fundTransfer(int id, int acc, double amount) {
		// TODO Auto-generated method stub
		dao.fundTransfer(id, acc, amount);
		try {
			jdao.fundTransfer(id, acc, amount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean idExist(int id) {
		// TODO Auto-generated method stub
		return dao.idExist(id);
	}

}
