package Main;

public class Transaction {
	
	private int id;
	private double amount, balance;
	private String type;

	
	public Transaction(int id,String type,double amount, double balance) {
		super();
		this.id=id;
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}
	
	

	public int getId() {
		return id;
	}



	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", balance=" + balance + ", type=" + type + "]";
	}

}
