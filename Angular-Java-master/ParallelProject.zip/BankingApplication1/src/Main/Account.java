package Main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

import Service.BankService;
import Service.BankServiceInterface;

public class Account {
	static int accno = 1001;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		BankServiceInterface service = new BankService();
		Customer cust;
		int id;
		String name, address = "", email, age, mobile;
		double balance = 0;

		System.out.println("Welcome to Apna Bank!!!");
		do {
			System.out.print("1. Create new Account\n2. Login\n3. Exit\nEnter your choice : ");
			int op = sc.nextInt();

			if (op == 1) {
				while (true) {
					System.out.print("Enter Your Name with first letter capital : ");
					name = sc.next();
					if (service.validateUserName(name)) {
						// cust.setName(name);
						break;
					}
				}

				while (true) {
					System.out.print("Enter Your Address without dot and commas : ");
					BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
					try {
						address = bf.readLine();
					} catch (Exception e) {
						e.printStackTrace();
					}

					if (service.validateUserAddress(address)) {
						// cust.setAddress(address);
						break;
					}
				}

				while (true) {
					System.out.print("Enter Your Age and Age must be above 15 : ");
					age = sc.next();
					if (service.validateUserAge(age)) {
						// cust.setAge(age);
						break;
					}
				}

				while (true) {
					System.out.print("Enter Your Email : ");
					email = sc.next();
					if (service.validateEmail(email)) {
						// cust.setEmail(email);
						break;
					} else {
						System.out.println("Enter khudka Email only..");
					}
				}

				while (true) {
					System.out.print("Enter Your Mobile Number : ");
					mobile = sc.next();
					if (service.validateMobile(mobile)) {
						// cust.setMobile(mobile);
						break;
					} else {
						System.out.println("Enter 10 digit without country code..");
					}
				}

				System.out.println("Customer Information saved successfully..");
				// cust.setAccountNo(accno);
				// cust.setBalance(balance);

				cust = new Customer(name, mobile, age, address, email, accno, balance);
				service.storeIntoBank(accno, cust);
				System.out.println("Your Account Details are : ");
				System.out.println(service.displayData(accno));
				accno++;
			}
			if (op == 2) {

				System.out.println("Enter your Account no: ");
				id = sc.nextInt();
				if (service.idExist(id)) {
					while (true) {
						System.out.print(
								"1. Show Balance\n2. Deposit\n3. Withdraw\n4. Fund Transfer\n5. Print Transactions\n6. Exit\nEnter your choice : ");
						op = sc.nextInt();
						if (op == 6)
							break;
						else {
							switch (op) {
							case 1:
								System.out.println(service.showBalance(id));
								break;

							case 2:
								System.out.println("Enter the amount to be deposited: ");
								service.Deposit(id, sc.nextDouble());
								// service.storeIntoBank(id,cust);
								break;

							case 3:
								System.out.println("Enter the amount to be withdraw: ");
								service.Withdraw(id, sc.nextDouble());
								// service.storeIntoBank(id,cust);
								break;

							case 4:
								System.out.println("Enter Recievers Account no: ");
								int acc = sc.nextInt();
								System.out.println("Enter the amount to be Transferred: ");
								service.fundTransfer(id, acc, sc.nextDouble());
								break;

							case 5:service.printTransactions(id);
								break;

							default:
								System.out.println("Invalid choice.");
								break;
							}
						}
					}
				}

				if (!service.idExist(id)) {
					System.out.println("Account no not Exist...");
				}
			}
			if (op == 3) {
				System.out.println("Thank you....");
				System.exit(0);
			}

		} while (true);

	}

}
