package Main;

public class Customer {
	private String name;
	private String mobile;
	private String age;
	private String address;
	private String email;
	private int accountNo;
	private double balance;
	
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Customer(String name, String mobile, String age, String address, String email, int accountNo,
			double balance) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.age = age;
		this.address = address;
		this.email = email;
		this.accountNo = accountNo;
		this.balance = balance;
	}



	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "Name = " + name + "\nMobile = " + mobile + "\nage = " + age
				+ "\naddress = " + address + "\nemail = " + email + "\naccountNo = "
				+ accountNo ;
	}

}
