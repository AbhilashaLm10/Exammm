package Lab1.four;

import Lab1.four.Employee;

public interface IDao {

	public void add(int id,Employee emp);
	public void display(int id);
}
