package Lab1.four;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Test4 {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Lab1.4.xml");
		IDao dao=ctx.getBean(Dao.class);
		int id;
		Scanner sc=new Scanner(System.in);
		Employee emp;
		while (true) {
			System.out.println("1.Create User\n2.Display user\n3.Exit");
			int opt=sc.nextInt();
			switch (opt) {
			case 1:
				System.out.println("Enter Id");
				 id=sc.nextInt();
				System.out.println("Enter Your Name");
				String name=sc.next();
				System.out.println("Enter Your Salary");
				double salary=sc.nextDouble();
				emp=new Employee(id, name, salary);
				dao.add(id, emp);
				break;

				case 2:System.out.println("Enter Id");
						id=sc.nextInt();
						dao.display(id);
						break;
						
				case 3:System.exit(0);
						break;
					
			default:
				break;
			}
			
		}
		
		
		
	}
	
}
