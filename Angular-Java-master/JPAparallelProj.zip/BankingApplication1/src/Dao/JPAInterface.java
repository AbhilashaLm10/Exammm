package Dao;

import java.sql.SQLException;

import Main.Customer;

public interface JPAInterface {
	
	public void openAccount(int id,Customer customer);
	double showBalance(int id);
	void Deposit(int id, double amount) throws SQLException;
	void Withdraw(int id,double amount);
	void fundTransfer(int id,int acc,double amount) throws SQLException;
	void printTransactions(int id);
	public int getMax();
	public boolean checkMobile(String mobile);
}
