package Dao;

import java.sql.SQLException;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.TypedQuery;

import org.hibernate.mapping.List;









import Main.Customer;
import Main.Transaction;

public class JPADao implements JPAInterface  {
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	Customer cust;
	Transaction txn;
	@Override
	public void openAccount(int id,Customer customer) {
		
			em.getTransaction().begin();
			em.persist(customer);
			em.getTransaction().commit();
	
		System.out.println("Added one student to database.");
			
	}

	@Override
	public double showBalance(int id) {
		cust=em.find(Customer.class, id);
		return cust.getBalance();
		
	}

	@Override
	public void Deposit(int id, double amount) throws SQLException {
		cust=em.find(Customer.class, id);
		double bal=cust.getBalance();
		bal+=amount;
		cust.setBalance(bal);
		txn=new Transaction("CR", amount, bal,id);
		em.getTransaction().begin();
		em.merge(cust);
		em.persist(txn);
		em.getTransaction().commit();
		
	}

	@Override
	public void Withdraw(int id, double amount) {
		// TODO Auto-generated method stub
		cust=em.find(Customer.class, id);
		double bal=cust.getBalance();
		if(bal>=amount){
			bal-=amount;
			cust.setBalance(bal);
			txn=new Transaction("DR", amount, bal,id);
			em.getTransaction().begin();
			em.merge(cust);
			em.persist(txn);
			em.getTransaction().commit();
		}else {
			System.out.println("Insufficient Balance");
		}
	}

	@Override
	public void fundTransfer(int id, int acc, double amount)
			throws SQLException {
		// TODO Auto-generated method stub
		cust=em.find(Customer.class, id);
		if(cust.getBalance()>=amount){
			Withdraw(id, amount);
			Deposit(acc, amount);
		}else {
			System.out.println("Insufficient Funds for Transfer");
		}
		
	}

	@Override
	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		String str="select txn from Transaction txn where txn.id=:pid";
		javax.persistence.TypedQuery<Transaction> query =em.createQuery(str,Transaction.class);
		query.setParameter("pid", id);
		java.util.List<Transaction> list1 = query.getResultList();
		for (Transaction transaction : list1) {
			System.out.println(transaction);
			
		}
		
	}

	public int getMax() {
		String str="select id from Customer id where id.accountNo=(select Max(c.accountNo) from Customer c)";
	Customer count;
	try {
		TypedQuery<Customer> q=em.createQuery(str, Customer.class);
		count = q.getSingleResult();
		return count.getAccountNo();
	} catch (Exception e) {
		return 1000;
	}
	}

	@Override
	public boolean checkMobile(String mobile) {
		// TODO Auto-generated method stub
		try {
			String str="select txn from Customer txn where txn.mobile=:pmobile";
			TypedQuery<Customer> q=em.createQuery(str, Customer.class);
			q.setParameter("pmobile", mobile);
			Customer cust=q.getSingleResult();
			if (cust!=null) {
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return true;
		}
		return true;
		
	}
}
