package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import Jdbc.JdbcUtil;
import Jdbc.QueryMapper;
import Main.Customer;

public class JdbcDao implements JdbcInterface {

	Customer acc = new Customer();
	// Account acc=new Account();
	Connection connection = null;
	PreparedStatement statement = null;

	public void openAccount(int id, Customer acc) {
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.insertDetails);

			statement.setInt(1, acc.getAccountNo());
			statement.setString(2, acc.getName());
			statement.setString(3, acc.getMobile());
			statement.setDouble(4, acc.getBalance());

			statement.executeUpdate();
			System.out.println("records added....");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (connection!=null) {
			try {
				connection.close();
					
				
			} catch (Exception e2) {
				// TODO: handle exception
			}}
		}
	}

	@Override
	public double showBalance(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void Deposit(int id, double amount) throws SQLException {
		// TODO Auto-generated method stub
		double bal;
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.sql);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				bal = rs.getDouble(4) + amount;
				// acc.setBalance(rs.getDouble(4)+amount);
				statement = connection.prepareStatement(QueryMapper.updateBal);
				statement.setDouble(1, bal);
				statement.setInt(2, id);
				statement.executeUpdate();
				
				statement = connection.prepareStatement(QueryMapper.inTxn);

				statement.setInt(1, id);
				statement.setString(2, "CR");
				statement.setDouble(3, amount);
				statement.setDouble(4, bal);

				statement.executeUpdate();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (connection!=null) {
			try {
				connection.close();
					
				
			} catch (Exception e2) {
				// TODO: handle exception
			}}
		}

	}

	@Override
	public void Withdraw(int id, double amount) {
		// TODO Auto-generated method stub
		double bal;
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.sql);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				bal = rs.getDouble(4);
				if(bal>=amount)
				 bal-=amount;
				// acc.setBalance(rs.getDouble(4)+amount);
				statement = connection.prepareStatement(QueryMapper.updateBal);
				statement.setDouble(1, bal);
				statement.setInt(2, id);
				statement.executeUpdate();
				
				statement = connection.prepareStatement(QueryMapper.inTxn);

				statement.setInt(1, id);
				statement.setString(2, "DR");
				statement.setDouble(3, amount);
				statement.setDouble(4, bal);

				statement.executeUpdate();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (connection!=null) {
			try {
				connection.close();
					
				
			} catch (Exception e2) {
				// TODO: handle exception
			}}
		}
	}

	@Override
	public void fundTransfer(int id, int acc, double amount) throws SQLException {
		// TODO Auto-generated method stub
		Withdraw(id, amount);
		Deposit(acc, amount);
	}

	@Override
	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.sqlTxn);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			//System.out.printf("%5s %3s %7s %7s","Account No","Type","Amount","Balance");
			while (rs.next()) {
				System.out.println("Account No: "+rs.getInt(1)+" Type: " +rs.getString(2)+" Amount: "+rs.getDouble(3)+" Balance: "+rs.getDouble(4));
				//System.out.format("%5d %3s %7d %7d", rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getDouble(4));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (connection!=null) {
			try {
				connection.close();
					
				
			} catch (Exception e2) {
				// TODO: handle exception
			}}
		}

	}

	@Override
	public boolean idExist(int id) {
		// TODO Auto-generated method stub
		return false;
	}
}
