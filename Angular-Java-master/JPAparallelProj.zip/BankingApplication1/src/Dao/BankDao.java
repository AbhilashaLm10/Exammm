package Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import Main.Customer;
import Main.Transaction;

public class BankDao implements BankDaoInterface {
Map<Integer, Customer> map=new HashMap<>();
List<Transaction> list=new ArrayList<>();

double balance;

@Override
public List<Customer> displayData(int id) {
	// TODO Auto-generated method stub
	List<Customer> list1=new ArrayList<>();
	list1.add(map.get(id));
	return list1;
}

@Override
public void storeIntoBank(int id, Customer customer) {
	// TODO Auto-generated method stub
	map.put(id, customer);
	
}

@Override
public double showBalance(int id) {
	// TODO Auto-generated method stub
	return map.get(id).getBalance();
}

@Override
public void Deposit(int id, double amount) {
	// TODO Auto-generated method stub
	balance=map.get(id).getBalance();
	balance+=amount;
	map.get(id).setBalance(balance);
	//list.add(new Transaction(id,"CR", amount, balance));
	//System.out.println(list);
	
}

@Override
public void Withdraw(int id, double amount) {
	// TODO Auto-generated method stub
	balance=map.get(id).getBalance();
	if (balance>amount) {
		balance-=amount;
		map.get(id).setBalance(balance);
		//list.add(new Transaction(id,"DR", amount, balance));
		//System.out.println(list);
	}
	else {
		System.out.println("Insufficient funds..");
	}
}

@Override
public void fundTransfer(int id, int acc, double amount) {
	// TODO Auto-generated method stub
	if(map.get(id).getBalance()>amount) {
		Withdraw(id, amount);
		Deposit(acc, amount);
		//System.out.println("Fund transfer:"+list);
		
	}
	
	
}

@Override
public void printTransactions(int id) {
	// TODO Auto-generated method stub
	for (Transaction transaction : list) {
		if(transaction.getId()==id)
			System.out.println(transaction);
	}

	
}

@Override
public boolean idExist(int id) {
	if(map.containsKey(id))
		return true;
	else
		return false;
}
	

	


}
