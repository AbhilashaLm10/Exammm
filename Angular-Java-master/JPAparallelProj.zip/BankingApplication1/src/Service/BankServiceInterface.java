package Service;

import java.util.List;

import Main.Customer;

public interface BankServiceInterface {
	String userNamePattern="[A-Z][a-z]{1,9}";
	String userNumberPattern="[0-9]{10}";
	/*String agePattern="[0-9]{2}";
	String userAddressPattern="^[a-zA-Z0-9_]+( [a-zA-Z0-9_]+)*$";
	String userMailPattern="^(.+)@(.+)$";*/
	
	boolean validateUserName(String userName);
	boolean validateMobile(String mobile);
	/*boolean validateUserAge(String userAge);
	boolean validateUserAddress(String userAddress);
	boolean validateEmail(String useraMail);*/
	
	
	public List<Customer> displayData(int id);
	void storeIntoBank(int id,Customer customer);
	public boolean idExist(int id);
	double showBalance(int id);
	void Deposit(int id, double amount);
	void Withdraw(int id,double amount);
	void fundTransfer(int id,int acc,double amount);
	void printTransactions(int id);
	public int getMax();

}
