package Service;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Dao.BankDao;
import Dao.BankDaoInterface;
import Dao.JPADao;
import Dao.JPAInterface;
import Dao.JdbcDao;
import Main.Customer;

public class BankService implements BankServiceInterface {
	BankDaoInterface dao = new BankDao();
	JdbcDao jdao = new JdbcDao();
JPAInterface jp=new JPADao();
	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateMobile(String mobile) {

		if (mobile.matches(userNumberPattern)) {
			if(jp.checkMobile(mobile)){
				return true;
		}else {
			System.out.println("Mobile no already exist..");
			return false;
		}
			}
		return false;
	}

	@Override
	public List<Customer> displayData(int id) {
		return dao.displayData(id);
	}

	/*
	 * 
	@Override
	public boolean validateUserAge(String userAge) {
		if (userAge.matches(agePattern)) {
			if (Integer.valueOf(userAge) > 15)
				return true;
		}
		return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean validateEmail(String useraMail) {
		if (useraMail.matches(userMailPattern)) {
			return true;
		}
		return false;
	}

	 * @Override public double showBalance(int id) { return
	 * customer.getBalance(); }
	 * 
	 * @Override public void Deposit(int id, double amount ) { double
	 * bal=customer.getBalance(); bal+=amount; customer.setBalance(bal); }
	 * 
	 * 
	 * @Override public void Withdraw(int id, double amount) { double
	 * bal=customer.getBalance(); if(bal>=amount) { bal-=amount;
	 * customer.setBalance(bal); } else
	 * System.out.println("Insufficient Fund!");
	 * 
	 * 
	 * }
	 * 
	 * @Override public void fundTransfer(int id,int acc,double amount) { double
	 * bal=customer.getBalance(); if(bal>=amount) { bal-=amount;
	 * System.out.println(amount+" Transferred to Account "+acc);
	 * customer.setBalance(bal); } else
	 * System.out.println("Insufficient Fund!");
	 * 
	 * 
	 * 
	 * }
	 */

	@Override
	public void storeIntoBank(int id, Customer customer) {
		dao.storeIntoBank(id, customer);
		jp.openAccount(id, customer);
		//jdao.openAccount(id, customer);

	}

	@Override
	public void printTransactions(int id) {
		// TODO Auto-generated method stub
		jp.printTransactions(id);
//		dao.printTransactions(id);
//		jdao.printTransactions(id);
	}

	@Override
	public double showBalance(int id) {
		// TODO Auto-generated method stub
		//return dao.showBalance(id);
		return jp.showBalance(id);
	}

	@Override
	public void Deposit(int id, double amount) {
		// TODO Auto-generated method stub
		try {
			jp.Deposit(id, amount);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//dao.Deposit(id, amount);
		/*try {
			jdao.Deposit(id, amount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	@Override
	public void Withdraw(int id, double amount) {
		// TODO Auto-generated method stub
		jp.Withdraw(id, amount);
//		dao.Withdraw(id, amount);
//		jdao.Withdraw(id, amount);
	}

	@Override
	public void fundTransfer(int id, int acc, double amount) {
		// TODO Auto-generated method stub
//		dao.fundTransfer(id, acc, amount);
		try {
			jp.fundTransfer(id, acc, amount);
//			jdao.fundTransfer(id, acc, amount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean idExist(int id) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		if(em.find(Customer.class, id)!=null){
			em.close();
			factory.close();
			return true;
		}else {
			em.close();
			factory.close();
			return false;
		}
	}
	
	public int getMax() {
		return jp.getMax();
		
	}

}
