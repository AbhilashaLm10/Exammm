package Main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name="TransactionData")
public class Transaction {
	@Id
	@Column(length=4)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sn;
	@ForeignKey(name = "accountNo")
	@Column(length=4)
	private int id;
	@Column(length=7)
	private double amount;
	@Column(length=7)
	private double balance;
	@Column(length=3)
	private String type;

	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(String type,double amount, double balance,int id) {
		//super();
		this.sn=sn;
		this.id=id;
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public int getSn() {
		return sn;
	}

	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", balance=" + balance + ", type=" + type + "]";
	}

}
