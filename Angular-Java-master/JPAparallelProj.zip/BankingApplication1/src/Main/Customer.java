package Main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="customerData")
public class Customer {
	@Id
	@Column(length=4)
	private int accountNo;
	@Column(length=20)
	private String name;
	@Column(length=10)
	private String mobile;
	@Column(length=7)
	private double balance;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int accountNo, String name, String mobile, double balance) {
		//super();
		this.accountNo = accountNo;
		this.name = name;
		this.mobile = mobile;
		this.balance = balance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", name=" + name
				+ ", mobile=" + mobile + ", balance=" + balance + "]";
	}

}
