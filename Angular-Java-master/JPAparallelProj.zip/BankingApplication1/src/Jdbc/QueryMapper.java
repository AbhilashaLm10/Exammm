package Jdbc;

public interface QueryMapper {

	String insertDetails ="insert into Customer(Account_no,Acc_Name,mobile,balance) values(?,?,?,?)";
	String sql="select * from Customer where Account_no=? ";
	String updateBal="Update Customer SET Balance =  ? where Account_no=?";
	
	String inTxn="insert into Transaction(Account_no,Type,Amount,balance) values(?,?,?,?)";
	String sqlTxn="select * from Transaction where Account_No=?";
}
