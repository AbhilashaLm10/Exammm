package bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile {
	@Id
	@Column(length=3)
	int id;
	@Column(length=15)
	String Name;
	@Column(length=7)
	double price;
	@Column(length=3)
	int quantity;
	
	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	
	public Mobile(int id, String name, double price, int quantity) {
		//super();
		this.id = id;
		Name = name;
		this.price = price;
		this.quantity = quantity;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public String toString() {
		return "[id=" + id + ", Name=" + Name + ", price=" + price + ", quantity=" + quantity + "]\n";
	}
	
	

}
