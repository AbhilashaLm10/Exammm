package bean;

import java.util.HashMap;
import java.util.Map;

public class Util {
	public static Map<Integer, Mobile> mob=new HashMap<>();

	public static Map<Integer, Mobile> getMob() {
		mob.put(101, new Mobile(101, "Sony", 12000, 10));
		mob.put(102, new Mobile(102, "Iphone", 15000, 8));
		mob.put(103, new Mobile(103, "Samsung",13000, 15));
		mob.put(104, new Mobile(104, "Nokia",10000,4));
		return mob;
	}

	
	
	

}
