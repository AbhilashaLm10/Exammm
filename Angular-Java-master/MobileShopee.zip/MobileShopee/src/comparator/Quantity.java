package comparator;

import java.util.Comparator;

import bean.Mobile;

public class Quantity implements Comparator<Mobile> {

	@Override
	public int compare(Mobile m1, Mobile m2) {
		// TODO Auto-generated method stub
		if ((m1.getQuantity())>(m2.getQuantity())) {
			return 1;
			
		} else if ((m1.getQuantity())==(m2.getQuantity())){
			return 0;

		}else {
			return -1;
		}
		//return m1.getQuantity().compareTo(m2.getQuantity());
	}

}
