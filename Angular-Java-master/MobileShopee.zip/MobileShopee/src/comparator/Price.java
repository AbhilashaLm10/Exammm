package comparator;

import java.util.Comparator;

import bean.Mobile;

public class Price implements Comparator<Mobile> {

	@Override
	public int compare(Mobile m1, Mobile m2) {

			if ((m1.getPrice())>(m2.getPrice())) {
				return 1;
				
			} else if ((m1.getPrice())==(m2.getPrice())){
				return 0;

			}else {
				return -1;
			}
	}

}
