package comparator;

import java.util.Comparator;

import bean.Mobile;

public class Name implements Comparator<Mobile> {

	@Override
	public int compare(Mobile m1,Mobile m2) {
		// TODO Auto-generated method stub
		return m1.getName().compareTo(m2.getName());
	}

}
