package Dao;

import java.util.List;

import bean.Mobile;

public interface DaoInterface {

	public void putData();
	public List<Mobile> getMobileList();
	public void deleteMobile(int id);
	public void sortByName();
	public void sortByPrice();
	public void sortByQuant();
	public void updateData(int id);
	
}
