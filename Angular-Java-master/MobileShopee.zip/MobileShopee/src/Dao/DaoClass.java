package Dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import bean.Mobile;
import bean.Util;
import comparator.Name;
import comparator.Price;
import comparator.Quantity;

public class DaoClass implements DaoInterface {
	
	List<Mobile> list1=new ArrayList<>();
	
	
	@Override
	public List<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		list1.addAll(Util.getMob().values());
		return list1;
	}

	@Override
	public void deleteMobile(int id) {
		// TODO Auto-generated method stub
		Map<Integer, Mobile> map=Util.getMob();
		if (map.containsKey(id)) {
			map.remove(id);
			System.out.println(map.values());
		} else {
			System.out.println("Invalid Id");
		}
	}

	@Override
	public void sortByName() {
		// TODO Auto-generated method stub
		Collections.sort(list1, new Name());
		for (Mobile mobile : list1) {
			System.out.println(mobile);
		}
		
	}

	@Override
	public void sortByPrice() {
		// TODO Auto-generated method stub
		Collections.sort(list1, new Price());
		for (Mobile mobile : list1) {
			System.out.println(mobile);
		}
		
	}

	@Override
	public void sortByQuant() {
		// TODO Auto-generated method stub
		Collections.sort(list1, new Quantity());
		for (Mobile mobile : list1) {
			System.out.println(mobile);
		}
	}

	@Override
	public void putData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateData(int id) {
		// TODO Auto-generated method stub
		
	}


}
