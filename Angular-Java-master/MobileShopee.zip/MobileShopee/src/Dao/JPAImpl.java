package Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import bean.Mobile;

public class JPAImpl implements DaoInterface {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	Mobile mob;

	@Override
	public List<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		String str="select mob from Mobile mob";
		TypedQuery<Mobile> q=em.createQuery(str, Mobile.class);
		List<Mobile> list=q.getResultList();
		return list;
	}

	@Override
	public void deleteMobile(int id) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		mob=em.find(Mobile.class, id);
		em.remove(mob);
		String str="select mob from Mobile mob";
		TypedQuery<Mobile> q=em.createQuery(str, Mobile.class);
		List<Mobile> list=q.getResultList();
		System.out.println(list);

	}

	@Override
	public void sortByName() {
		// TODO Auto-generated method stub
		String str="select mob from Mobile mob ORDER BY mob.Name";
		TypedQuery<Mobile> q=em.createQuery(str, Mobile.class);
		List<Mobile> list=q.getResultList();
		System.out.println(list);
	}

	@Override
	public void sortByPrice() {
		// TODO Auto-generated method stub
		String str="select mob from Mobile mob ORDER BY mob.price";
		TypedQuery<Mobile> q=em.createQuery(str, Mobile.class);
		List<Mobile> list=q.getResultList();
		System.out.println(list);
	}

	@Override
	public void sortByQuant() {
		// TODO Auto-generated method stub
		String str="select mob from Mobile mob ORDER BY mob.quantity";
		TypedQuery<Mobile> q=em.createQuery(str, Mobile.class);
		List<Mobile> list=q.getResultList();
		System.out.println(list);

	}

	@Override
	public void putData() {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(new Mobile(101, "Sony", 12000, 10));
		em.persist(new Mobile(102, "Iphone", 15000, 8));
		em.persist(new Mobile(103, "Samsung",13000, 15));
		em.persist(new Mobile(104, "Nokia",10000,4));
		em.getTransaction().commit();
		
	}
	
	@Override
	public void updateData(int id) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		mob=em.find(Mobile.class, id);
		mob.setQuantity(6);
		em.merge(mob);
		em.getTransaction().commit();
		
	}

}
