package Service;

import java.util.List;

import Dao.DaoClass;
import Dao.DaoInterface;
import Dao.JPAImpl;
import bean.Mobile;

public class MobileService implements MobileServiceInterface {

	DaoInterface dao=new DaoClass();
	DaoInterface jpa=new JPAImpl();
	
	@Override
	public boolean validateChoice(String option) {
		// TODO Auto-generated method stub
		if (option.matches(pattern1)) {
			return true;
			
		}
		return false;
	}

	@Override
	public boolean validateCriteria(String criteria) {
		// TODO Auto-generated method stub
		if (criteria.matches(pattern2)) {
			return true;
		}
		return false;
	}

	@Override
	public List<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		return jpa.getMobileList();
	}

	@Override
	public void deleteMobile(int id) {
		// TODO Auto-generated method stub
		jpa.deleteMobile(id);
		//dao.deleteMobile(id);
		
	}

	@Override
	public void sortByName() {
		// TODO Auto-generated method stub
		jpa.sortByName();
		//dao.sortByName();
	}

	@Override
	public void sortByPrice() {
		// TODO Auto-generated method stub
		jpa.sortByPrice();
		//dao.sortByPrice();
	}

	@Override
	public void sortByQuant() {
		// TODO Auto-generated method stub
		jpa.sortByQuant();
		//dao.sortByQuant();
	}

	@Override
	public void putData() {
		// TODO Auto-generated method stub
		jpa.putData();
		
	}

	@Override
	public void updateData(int id) {
		// TODO Auto-generated method stub
		jpa.updateData(id);
	}


}
