package Service;

import java.util.List;

import bean.Mobile;

public interface MobileServiceInterface {
	String pattern1="[1-4]{1}";
	String pattern2="[1-3]{1}";
	
	boolean validateChoice(String option);
	boolean validateCriteria(String criteria);
	public List<Mobile> getMobileList();
	public void deleteMobile(int id);
	public void sortByName();
	public void sortByPrice();
	public void sortByQuant();
	public void putData();
	void updateData(int id);

}