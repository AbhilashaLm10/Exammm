package Main;

import java.util.Scanner;

import Service.MobileService;
import Service.MobileServiceInterface;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int option,criteria;
		MobileServiceInterface service =new MobileService();
		//service.putData();
		System.out.println("Welcome to Raza Mobile Shoppee");
		System.out.println(service.getMobileList());
		while (true) {
			System.out.println("1. Sorting\n2. Delete\n3. Update\n4. Exit");
				option=sc.nextInt();
			if (service.validateChoice(String.valueOf(option))) {
				break;
			}
		}
		
		if (option==1) {
			while (true) {
				System.out.println("1. Sort by Name\n2. Sort by Price\n3.Sort by Quantity");
					criteria=sc.nextInt();
				if (service.validateCriteria(String.valueOf(criteria))) {
					break;
				}
			}
			switch (criteria) {
			case 1:service.sortByName();
					break;
			case 2:service.sortByPrice();
			break;
			case 3:service.sortByQuant();
			break;
			default:System.out.println("Invalid option");
				break;
			}
		}
		else if (option==2) {
			System.out.println("Enter id to be deleted: ");
			service.deleteMobile(sc.nextInt());
		}
		else if (option==3) {
			System.out.println("Enter id to be Updated: ");
			service.updateData(sc.nextInt());
		}
		else if (option==4) {
			System.out.println("Thank you... ");
			System.exit(0);
		}
		else {
			System.out.println("Invalid Option");
		}
		
	}

}
