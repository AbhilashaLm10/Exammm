export class Pizza {
    public orderId: number;
    public custName: string;
    public ordered: string;
    public price: number;
    public mobile: number;
}
